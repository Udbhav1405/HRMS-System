import { Employee, AttendanceLog, LeaveRequest, Department } from '../types';

export const INITIAL_DEPARTMENTS_LIST: Department[] = [
  {
    id: 'DEPT-EXEC',
    name: 'Executive',
    managerName: 'Abhishek Mishra',
    description: 'Executive corporate leadership, strategic directives, operations oversight, and organizational management.'
  },
  {
    id: 'DEPT-HR',
    name: 'Human Resources',
    managerName: 'Aruhi Gautam',
    description: 'Human Resources, employee operations, talent management, and organizational policy.'
  },
  {
    id: 'DEPT-IT',
    name: 'Information Technology',
    managerName: 'Udbhav Singh',
    description: 'Software development, system engineering, technical infrastructure, and IT support.'
  },
  {
    id: 'DEPT-SM',
    name: 'Social Media',
    managerName: 'Not Assigned',
    description: 'Social media growth, creative content, multi-platform brand management, and community engagement.'
  },
  {
    id: 'DEPT-DM',
    name: 'Digital Marketing',
    managerName: 'Udbhav Singh',
    description: 'Digital marketing campaigns, SEO/SEM strategies, online brand outreach, and conversion analytics.'
  },
  {
    id: 'DEPT-SALES',
    name: 'Sales and Marketing',
    managerName: 'Abhishek Mishra',
    description: 'Client acquisition, business development, sales pipeline management, and strategic marketing outreach.'
  }
];

export const PDF_EMPLOYEES: Employee[] = [
  {
    id: "EMP-001",
    name: "Udbhav Singh",
    email: "threadtechnologies2025@gmail.com",
    role: "admin",
    department: "Information Technology",
    phone: "+91 92140 14284",
    address: "Gomti nagar",
    emergencyContact: "",
    salary: "INR 25,000",
    joinDate: "2022-01-15",
    avatarColor: "bg-indigo-600 text-white",
    avatarUrl: "",
    status: "working",
    jobTitle: "Admin Head",
    password: "Udk456@123"
  },
  {
    id: "TT26MD01",
    name: "Abhishek Mishra",
    email: "mishraabhishek5814@gmail.com",
    role: "manager",
    department: "Executive",
    phone: "+91 96705 98347",
    address: "Gomti nagar",
    emergencyContact: "",
    salary: "INR 25,000",
    joinDate: "2026-03-26",
    avatarColor: "bg-indigo-700 text-white",
    avatarUrl: "",
    status: "working",
    jobTitle: "Managing Director",
    password: "Am14@09"
  },
  {
    id: "TT26HR01",
    name: "Aruhi Gautam",
    email: "aruhigautam3@gmail.com",
    role: "hr",
    department: "Human Resources",
    phone: "+91 90606 96694",
    address: "Vinamra Khand, Gomti Nagar, Lko",
    emergencyContact: "",
    salary: "INR 10,000",
    joinDate: "2026-07-02",
    avatarColor: "bg-rose-600 text-white",
    avatarUrl: "",
    status: "working",
    jobTitle: "Human Resources",
    password: "Ag03@01"
  },
  {
    id: "TT26IT013",
    name: "Anjali Upadhyay",
    email: "anjaliupadhyay733@gmail.com",
    role: "employee",
    department: "Information Technology",
    phone: "+91 78601 87498",
    address: "Vinamra Khand, Gomti Nagar, Lko",
    emergencyContact: "",
    salary: "INR 10,000",
    joinDate: "2026-07-02",
    avatarColor: "bg-blue-600 text-white",
    avatarUrl: "",
    status: "working",
    jobTitle: "Software Developer",
    password: "Au33@13"
  },
  {
    id: "TT26SM01",
    name: "Aradhya Dixit",
    email: "aradhyadixit014@gmail.com",
    role: "employee",
    department: "Sales and Marketing",
    phone: "+91 91204 17414",
    address: "Kapurthala Ghosiyana Rd, Lakhimpur",
    emergencyContact: "",
    salary: "INR 10,000",
    joinDate: "2026-06-29",
    avatarColor: "bg-amber-600 text-white",
    avatarUrl: "",
    status: "working",
    jobTitle: "Sales and Marketing",
    password: "Ad14@01"
  },
  {
    id: "TT26SM02",
    name: "Anurag Verma",
    email: "anurag266verma@gmail.com",
    role: "employee",
    department: "Sales and Marketing",
    phone: "+91 96964 45218",
    address: "Panchsheel Aashray, Sector 3, Jankipuram",
    emergencyContact: "",
    salary: "INR 9,000",
    joinDate: "2026-07-22",
    avatarColor: "bg-emerald-600 text-white",
    avatarUrl: "",
    status: "working",
    jobTitle: "Sales and Marketing",
    password: "Av66@02"
  },
  {
    id: "TT26SM03",
    name: "Sarika Dubey",
    email: "dubeysarika295@gmail.com",
    role: "employee",
    department: "Sales and Marketing",
    phone: "+91 88107 84564",
    address: "Vikalp khand 2/500 gaurav girls pg",
    emergencyContact: "",
    salary: "INR 8,000",
    joinDate: "2026-08-17",
    avatarColor: "bg-teal-600 text-white",
    avatarUrl: "",
    status: "working",
    jobTitle: "Sales and Marketing",
    password: "AS95@03"
  },
  {
    id: "TT26IT014",
    name: "Ankit Kumar",
    email: "ankitsinghkunnu@gmail.com",
    role: "employee",
    department: "Information Technology",
    phone: "+91 62073 94734",
    address: "Matiyari, Gomti Nagar, Lko",
    emergencyContact: "",
    salary: "INR 10,000",
    joinDate: "2026-06-29",
    avatarColor: "bg-slate-600 text-white",
    avatarUrl: "",
    status: "not working",
    jobTitle: "Software Developer",
    password: "Ak29@06"
  },
  {
    id: "TT26DM01",
    name: "Anjali Kumari",
    email: "anjalirai1227@gmail.com",
    role: "employee",
    department: "Digital Marketing",
    phone: "+91 97089 54315",
    address: "Jankipuram, Alisha Nagar Colony, Lko",
    emergencyContact: "",
    salary: "INR 10,000",
    joinDate: "2026-07-05",
    avatarColor: "bg-purple-600 text-white",
    avatarUrl: "",
    status: "internship completed",
    jobTitle: "Digital Marketing Executive",
    password: "Ak05@07"
  }
];

export const PDF_LEAVE_REQUESTS: LeaveRequest[] = [];

export const PDF_ATTENDANCE_LOGS: AttendanceLog[] = [];

export const TODAY_PUNCH_IN_TIMES: { [empId: string]: { time: string; date: string } } = {};
