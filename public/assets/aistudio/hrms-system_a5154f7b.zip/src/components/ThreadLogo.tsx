import React from 'react';

interface ThreadLogoProps {
  size?: number;
  className?: string;
}

export const ThreadLogo: React.FC<ThreadLogoProps> = ({ size = 32, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none ${className}`}
      id="thread-technologies-logo-svg"
    >
      <defs>
        {/* Blue/Cyan gradient for left T */}
        <linearGradient id="blueGradient" x1="18" y1="46" x2="72" y2="94" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#0284c7" />
          <stop offset="50%" stopColor="#0ea5e9" />
          <stop offset="100%" stopColor="#1d4ed8" />
        </linearGradient>

        {/* Green/Lime gradient for right T */}
        <linearGradient id="greenGradient" x1="52" y1="46" x2="102" y2="94" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#84cc16" />
          <stop offset="60%" stopColor="#22c55e" />
          <stop offset="100%" stopColor="#15803d" />
        </linearGradient>

        {/* Silver gradient for the metallic flowing wave */}
        <linearGradient id="silverGradient" x1="14" y1="76" x2="106" y2="60" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#e2e8f0" />
          <stop offset="30%" stopColor="#94a3b8" />
          <stop offset="70%" stopColor="#cbd5e1" />
          <stop offset="100%" stopColor="#f1f5f9" />
        </linearGradient>

        {/* Green/Cyan glow gradient for nodes */}
        <radialGradient id="glowNode" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#22c55e" stopOpacity="1" />
          <stop offset="100%" stopColor="#22c55e" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* 1. TOP GLOBE/NETWORK (Green connection dome) */}
      <g id="logo-top-network">
        {/* Network connections (curves) */}
        <ellipse cx="60" cy="40" rx="35" ry="12" fill="none" stroke="#84cc16" strokeWidth="1.2" strokeDasharray="3 1.5" opacity="0.5" transform="rotate(-15 60 40)" />
        <ellipse cx="60" cy="40" rx="32" ry="18" fill="none" stroke="#22c55e" strokeWidth="1.2" strokeDasharray="4 2" opacity="0.6" transform="rotate(10 60 40)" />
        <path d="M 28 42 A 32 32 0 0 1 92 42" fill="none" stroke="#4ade80" strokeWidth="1.5" strokeLinecap="round" opacity="0.7" />
        <path d="M 38 42 A 22 22 0 0 1 82 42" fill="none" stroke="#22c55e" strokeWidth="1.2" opacity="0.8" />
        <path d="M 24 42 Q 60 12 96 42" fill="none" stroke="#84cc16" strokeWidth="1.8" strokeLinecap="round" />
        
        {/* Network connection intersection lines */}
        <path d="M 60 12 L 60 42" fill="none" stroke="#a3e635" strokeWidth="0.8" opacity="0.4" />
        <path d="M 40 22 L 80 22" fill="none" stroke="#a3e635" strokeWidth="0.8" opacity="0.4" />

        {/* Top green nodes */}
        <circle cx="60" cy="12" r="3.5" fill="#84cc16" />
        <circle cx="60" cy="12" r="6" fill="url(#glowNode)" opacity="0.3" />
        <circle cx="41" cy="23" r="3" fill="#22c55e" />
        <circle cx="79" cy="23" r="3" fill="#84cc16" />
        <circle cx="96" cy="42" r="3.5" fill="#22c55e" />
        <circle cx="24" cy="42" r="3.5" fill="#84cc16" />
      </g>

      {/* 2. LOWER ORBITAL CIRCLES & NODES (Blue, Cyan, Purple orbits) */}
      <g id="logo-bottom-orbits" opacity="0.85">
        {/* Orbit curves */}
        <path d="M 24 45 C 8 62, 12 88, 35 102 C 58 116, 92 110, 102 88 C 108 75, 102 58, 96 45" fill="none" stroke="#0ea5e9" strokeWidth="1.2" strokeLinecap="round" />
        <path d="M 18 55 C 4 75, 22 108, 60 112 C 98 116, 114 85, 106 55" fill="none" stroke="#a855f7" strokeWidth="1.2" strokeDasharray="3 3" />
        <path d="M 32 45 C 22 65, 42 98, 60 98 C 78 98, 98 65, 88 45" fill="none" stroke="#06b6d4" strokeWidth="1" opacity="0.5" />

        {/* Orbit nodes */}
        <circle cx="28" cy="94" r="3" fill="#0ea5e9" />
        <circle cx="60" cy="111" r="3.5" fill="#06b6d4" />
        <circle cx="92" cy="92" r="3" fill="#a855f7" />
        <circle cx="16" cy="74" r="2.5" fill="#3b82f6" />
        <circle cx="104" cy="74" r="2.5" fill="#a855f7" />
        <circle cx="46" cy="105" r="2" fill="#06b6d4" />
        <circle cx="78" cy="104" r="2" fill="#8b5cf6" />
      </g>

      {/* 3. INTERTWINED "T" SHAPES */}
      <g id="logo-stems">
        {/* Blue T - horizontal bar */}
        <path
          d="M 18 54 C 18 48, 30 46, 52 46 C 62 46, 72 47, 76 50"
          fill="none"
          stroke="url(#blueGradient)"
          strokeWidth="8.5"
          strokeLinecap="round"
        />
        {/* Blue T - vertical stem */}
        <path
          d="M 47 49 L 47 96"
          fill="none"
          stroke="url(#blueGradient)"
          strokeWidth="8.5"
          strokeLinecap="round"
        />

        {/* Green T - horizontal bar */}
        <path
          d="M 52 50 C 58 47, 70 46, 92 46 C 102 46, 102 52, 102 54"
          fill="none"
          stroke="url(#greenGradient)"
          strokeWidth="8.5"
          strokeLinecap="round"
        />
        {/* Green T - vertical stem */}
        <path
          d="M 71 49 L 71 96"
          fill="none"
          stroke="url(#greenGradient)"
          strokeWidth="8.5"
          strokeLinecap="round"
        />
      </g>

      {/* 4. SILVERY WAVE WITH PURPLE NODES (Passes over stems) */}
      <g id="logo-wave">
        {/* Silver wave */}
        <path
          d="M 14 77 C 32 61, 40 56, 58 72 C 72 84, 88 74, 106 61"
          fill="none"
          stroke="url(#silverGradient)"
          strokeWidth="5"
          strokeLinecap="round"
        />
        
        {/* Small purple nodes on the silver wave */}
        <circle cx="43" cy="65.5" r="3.5" fill="#a855f7" stroke="#ffffff" strokeWidth="1" />
        <circle cx="89" cy="67.5" r="3.5" fill="#c084fc" stroke="#ffffff" strokeWidth="1" />
      </g>
    </svg>
  );
};
