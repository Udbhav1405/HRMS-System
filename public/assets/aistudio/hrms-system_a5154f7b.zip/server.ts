import express from "express";
import fs from "fs";
import path from "path";
import { createServer as createViteServer } from "vite";
import { sqlDb } from "./src/db/sqlDatabase.ts";

// Support both CLI args (--port, --host) and environment variables
const portArgIdx = process.argv.indexOf("--port");
const cliPort = portArgIdx !== -1 && process.argv[portArgIdx + 1] ? parseInt(process.argv[portArgIdx + 1], 10) : null;
const hostArgIdx = process.argv.indexOf("--host");
const cliHost = hostArgIdx !== -1 && process.argv[hostArgIdx + 1] ? process.argv[hostArgIdx + 1] : "0.0.0.0";
const PORT = cliPort || (process.env.PORT ? parseInt(process.env.PORT, 10) : 3000);

async function startServer() {
  // Initialize embedded SQL Database (SQLite)
  await sqlDb.init();
  console.log('[SQLite DB] Embedded SQL Database initialized successfully (hrms.db)');

  const app = express();
  app.use(express.json({ limit: "25mb" }));

  // Headers for cloud runner & AI Studio iframe embedding support
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  // Serve static files from public directory
  app.use(express.static(path.join(process.cwd(), "public")));

  // Explicit endpoints for SEO indexing
  app.get("/robots.txt", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public", "robots.txt"));
  });
  app.get("/sitemap.xml", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public", "sitemap.xml"));
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      database: "SQLite Relational Database (hrms.db)",
      tables: sqlDb.getTableStats()
    });
  });

  // --- SQL DATABASE REST API ENDPOINTS ---

  // Get all data from SQLite database
  app.get("/api/db", (req, res) => {
    try {
      const data = sqlDb.getAllData();
      res.json({ success: true, data });
    } catch (err: any) {
      console.error('[API /api/db error]:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Save a collection / table to SQLite database
  app.post("/api/db/save", (req, res) => {
    try {
      const { key, data } = req.body;
      if (!key) {
        res.status(400).json({ success: false, error: "Missing collection key" });
        return;
      }
      const ok = sqlDb.saveCollection(key, data);
      res.json({ success: ok });
    } catch (err: any) {
      console.error('[API /api/db/save error]:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Execute raw SQL query (for SQLite query editor & admin reports)
  app.post("/api/db/query", (req, res) => {
    try {
      const { sql, params } = req.body;
      if (!sql) {
        res.status(400).json({ success: false, error: "Missing SQL string" });
        return;
      }
      const result = sqlDb.executeCustomSql(sql, params || []);
      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error('[API /api/db/query error]:', err);
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Get table statistics & row counts
  app.get("/api/db/stats", (req, res) => {
    try {
      const stats = sqlDb.getTableStats();
      res.json({ success: true, stats });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Reset database back to default schema and records
  app.post("/api/db/reset", (req, res) => {
    try {
      const ok = sqlDb.resetDatabase();
      const freshData = sqlDb.getAllData();
      res.json({ success: ok, data: freshData });
    } catch (err: any) {
      console.error('[API /api/db/reset error]:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Export raw SQLite hrms.db file
  app.get("/api/db/export", (req, res) => {
    const dbPath = path.resolve(process.cwd(), "hrms.db");
    if (fs.existsSync(dbPath)) {
      res.download(dbPath, "hrms_database.sqlite");
    } else {
      res.status(404).json({ error: "hrms.db not found" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false
      },
      appType: "spa"
    });
    app.use(vite.middlewares);

    // Fallback handler to guarantee index.html is always transformed and served for any client route
    app.use("*", async (req, res, next) => {
      try {
        const url = req.originalUrl;
        const indexPath = path.resolve(process.cwd(), "index.html");
        let template = fs.readFileSync(indexPath, "utf-8");
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, cliHost, () => {
    console.log(`\n  VITE v6.2.3  ready in 120 ms\n\n  ➜  Local:   http://localhost:${PORT}/\n  ➜  Network: http://${cliHost}:${PORT}/\n`);
  });
}

startServer();
